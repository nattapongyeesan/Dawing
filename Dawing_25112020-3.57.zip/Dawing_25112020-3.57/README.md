# Simple Drawing Web App
[Video Guide](https://youtu.be/amXSWXQssww)
